package org.apache.camel;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.weaver.MatchType;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.nr.instrumentation.apache.camel.CamelHeaders;
import com.nr.instrumentation.apache.camel.Util;

@Weave(type=MatchType.Interface)
public abstract class Endpoint {

	
	public abstract String getEndpointUri();
	
	
	public Exchange createExchange() {
		Exchange exchange = Weaver.callOriginal();
		CamelHeaders headers = new CamelHeaders(exchange);
		NewRelic.getAgent().getTransaction().insertDistributedTraceHeaders(headers);
		return exchange;
	}
	
	
	public Exchange createExchange(ExchangePattern pattern) {
		Exchange exchange = Weaver.callOriginal();
		CamelHeaders headers = new CamelHeaders(exchange);
		NewRelic.getAgent().getTransaction().insertDistributedTraceHeaders(headers);
		if(exchange instanceof ExtendedExchange) {
			Util.addCompletionIfNeeded((ExtendedExchange)exchange);
		}
		
		return exchange;
	}

}
